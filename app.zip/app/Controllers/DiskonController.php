<?php

namespace App\Controllers;

use App\Models\DiskonModel;

class DiskonController extends BaseController
{
    protected $diskonModel;

    public function __construct()
    {
        $this->diskonModel = new DiskonModel();
    }

    public function index()
    {
        $editData = null;
        if ($this->request->getGet('edit')) {
            $editData = $this->diskonModel->find($this->request->getGet('edit'));
        }

        $data = [
            'title' => 'Data Diskon',
            'diskon' => $this->diskonModel->orderBy('tanggal', 'ASC')->findAll(),
            'editData' => $editData
        ];

        return view('v_diskon', $data);
    }

    public function save()
    {
        $id = $this->request->getPost('id');

        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nominal' => $this->request->getPost('nominal'),
        ];

        if ($id) {
            $this->diskonModel->update($id, $data);
        } else {
            $this->diskonModel->insert($data);
        }

        return redirect()->to('/diskon');
    }

    public function delete($id)
    {
        $this->diskonModel->delete($id);
        return redirect()->to('/diskon');
    }
}
